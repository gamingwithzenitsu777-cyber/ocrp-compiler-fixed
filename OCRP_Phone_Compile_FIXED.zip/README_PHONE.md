# OCRP phone compiler package

Upload the contents of this folder to your GitHub repository.

Then open Actions -> Compile OCRP Pawn Gamemode -> Run workflow.
The workflow builds gamemodes/ocrp.amx and uploads it as the OCRP-AMX artifact.

The workflow uses the SA-MP 0.3.7-R2-2-1 include package plus the Pawn standard library.
